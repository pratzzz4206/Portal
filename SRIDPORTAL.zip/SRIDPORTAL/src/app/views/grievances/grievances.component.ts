import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grievances',
  templateUrl: './grievances.component.html',
  styleUrls: ['./grievances.component.css']
})
export class GrievancesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
