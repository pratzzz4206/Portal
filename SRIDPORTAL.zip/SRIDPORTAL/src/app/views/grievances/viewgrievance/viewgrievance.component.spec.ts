import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewgrievanceComponent } from './viewgrievance.component';

describe('ViewgrievanceComponent', () => {
  let component: ViewgrievanceComponent;
  let fixture: ComponentFixture<ViewgrievanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewgrievanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewgrievanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
