import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewgrievance',
  templateUrl: './viewgrievance.component.html',
  styleUrls: ['./viewgrievance.component.css']
})
export class ViewgrievanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
