import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { grievanceService } from '../grievances.service';

@Component({
  selector: 'app-viewgrievance',
  templateUrl: './viewgrievance.component.html',
  styleUrls: ['./viewgrievance.component.css']
})
export class ViewgrievanceComponent implements OnInit {

  displayedColumns: string[] = ['Title', 'Type', 'SubType', 'Details'];
  dataSource = new MatTableDataSource();

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  GrievanceData :any
  TableSource=[]
  constructor( private gService:grievanceService) { 
    this.GrievanceData=this.gService.getGrievance();
    for (let i = 0; i <this.GrievanceData.length; i++) {
      this.TableSource.push(this.GrievanceData[i]);
      this.dataSource.data=this.TableSource
    }
  }

  ngOnInit() {

    this.GrievanceData=this.gService.getGrievance();
    this.gService.DataUpdated.subscribe( () =>{
      
      this.GrievanceData=this.gService.getGrievance();
      this.TableSource=[]
      for (let i = 0; i <this.GrievanceData.length; i++) {
        this.TableSource.push(this.GrievanceData[i]);
      }
      console.log(this.TableSource)
      this.dataSource.data=this.TableSource
    });

    
  }

}
