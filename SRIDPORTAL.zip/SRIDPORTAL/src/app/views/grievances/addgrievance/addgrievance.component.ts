import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, NgForm} from '@angular/forms';
import { grievanceService } from '../grievances.service';

export interface Food {
  value: string;
  viewValue: string;
}

export interface Animal {
  name: string;
  
}

@Component({
  selector: 'app-addgrievance',
  templateUrl: './addgrievance.component.html',
  styleUrls: ['./addgrievance.component.css']
})


export class AddgrievanceComponent implements OnInit {

  constructor( private gService:grievanceService) { }

  ngOnInit() {
  }


  isCollapsed: boolean = false;

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    // console.log(event);
  }

  email = new FormControl('', [Validators.required]);

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :'';
  }

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

  animalControl = new FormControl('', [Validators.required]);
  animal2Control = new FormControl('', [Validators.required]);
  gDetails = new FormControl('', [Validators.required]);
  animals: Animal[] = [
    {name: 'Dog'},
    {name: 'Cat'},
    {name: 'Cow'},
    {name: 'Fox'},
  ];

  onSubmit(Form:NgForm){
    
    
    const body = {
      'Title' : Form.value.grieTitle,
      'Type' : Form.value.grieType.name,
      'SubType' : Form.value.grieSType.name,
      'Details' : Form.value.grieDetails,
      'Anonymous' : Form.value.inline,
      'Files' : Form.value.file
    };

    this.gService.addGrievance(body);
  }
  
}
