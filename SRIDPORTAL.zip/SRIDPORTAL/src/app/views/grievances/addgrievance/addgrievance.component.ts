import { Component, OnInit,SecurityContext, ViewEncapsulation } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { AlertConfig } from 'ngx-bootstrap/alert';

import {FormControl, Validators, NgForm} from '@angular/forms';
import { grievanceService } from '../grievances.service';
import {MatTableDataSource} from '@angular/material/table';

export interface Food {
  name: string;
}

export interface Animal {
  name: string;
  
}





@Component({
  selector: 'app-addgrievance',
  templateUrl: './addgrievance.component.html',
  styleUrls: ['./addgrievance.component.css']
})


export class AddgrievanceComponent implements OnInit {

  displayedColumns: string[] = ['Title', 'Type', 'SubType', 'Details'];
  dataSource = new MatTableDataSource();

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  GrievanceData :any
  TableSource=[]
  constructor( private gService:grievanceService) { 
    this.GrievanceData=this.gService.getGrievance();
    for (let i = 0; i <this.GrievanceData.length; i++) {
      this.TableSource.push(this.GrievanceData[i]);
      this.dataSource.data=this.TableSource
    }
  }

  ngOnInit() {

    this.GrievanceData=this.gService.getGrievance();
    this.gService.DataUpdated.subscribe( () =>{
      
      this.GrievanceData=this.gService.getGrievance();
      this.TableSource=[]
      for (let i = 0; i <this.GrievanceData.length; i++) {
        this.TableSource.push(this.GrievanceData[i]);
      }
      console.log(this.TableSource)
      this.dataSource.data=this.TableSource
    });

    
  }

 
  isCollapsed: boolean = false;

  collapsed(event: any): void {
    // console.log(event);
  }

  expanded(event: any): void {
    // console.log(event);
  }

  email = new FormControl('', [Validators.required]);

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :'';
  }

  foods: Food[] = [
    {name: 'HR'},
    {name: 'SE'},
    {name: 'Cloud'},
    {name: 'Platform'},
  ];

  animalControl = new FormControl('', [Validators.required]);
  animal2Control = new FormControl('', [Validators.required]);
  gDetails = new FormControl('', [Validators.required]);
  animals: Animal[] = [
    {name: 'GA'},
    {name: 'Finance'},
    {name: 'B2C'},
    {name: 'SPE'},
  ];

  onSubmit(Form:NgForm){
    
    
    const body = {
      'Title' : Form.value.grieTitle,
      'Type' : Form.value.grieType.name,
      'SubType' : Form.value.grieSType.name,
      'Details' : Form.value.grieDetails,
      'Anonymous' : Form.value.inline,
      'Files' : Form.value.file
    };

    this.gService.addGrievance(body);

    this.add();
    
  }

  alertsDismiss: any = [];
  add(): void {
    this.alertsDismiss=[]
    this.alertsDismiss.push({
      type: 'success',
      
      timeout: 2000
    });
  }
  
  
}
