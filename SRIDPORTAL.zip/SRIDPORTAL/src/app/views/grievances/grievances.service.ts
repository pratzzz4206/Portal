import { Observable } from 'rxjs';

export class grievanceService{
    private GrievanceData=[];

    addGrievance(value: any) {
        this.GrievanceData.push(value);
        console.log(this.GrievanceData)
    }

    getGrievance(){
        return [...this.GrievanceData];
    }
}