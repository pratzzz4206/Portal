import { Observable,Subject } from 'rxjs';

export class grievanceService{
    private  GrievanceData=[];
    DataUpdated = new Subject;

    addGrievance(value: any) {
        this.GrievanceData.push(value);
        this.DataUpdated.next();
        
        
    }

    getGrievance(){
        
        return [...this.GrievanceData];
        
    }
}