import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { grievancesRoutingModule } from './grievances-routing.module';
import { BsDropdownModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddgrievanceComponent } from './addgrievance/addgrievance.component';
import { GrievancesComponent } from './grievances.component';
import { ViewgrievanceComponent } from './viewgrievance/viewgrievance.component';
import { materialModule } from '../../material.module';
import { grievanceService } from './grievances.service';
import { CollapseModule } from 'ngx-bootstrap/collapse';

@NgModule({
    imports:[CommonModule,grievancesRoutingModule,BsDropdownModule.forRoot(),FormsModule,materialModule,ReactiveFormsModule,CollapseModule.forRoot()],
    declarations:[AddgrievanceComponent,GrievancesComponent,ViewgrievanceComponent],
    exports:[],
    providers:[grievanceService]
})
export class grievancesModule{

}