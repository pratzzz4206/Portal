import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GrievancesComponent } from './grievances.component';
import { AddgrievanceComponent } from './addgrievance/addgrievance.component';
import { ViewgrievanceComponent } from './viewgrievance/viewgrievance.component';
import { AssignedgrievanceComponent } from './assignedgrievance/assignedgrievance.component';


const routes: Routes = [
    {
      path: '',
      data: {
        title: 'Grievances'
      },
      children: [
        {
          path: '',
          redirectTo: 'addgrievance'
        },
        {
          path: '',
          component: GrievancesComponent,
          data: {
            title: 'Grievances'
          }
        },
        {
          path: 'addgrievance',
          component: AddgrievanceComponent,
          data: {
            title: 'Add Grievance'
          }
        },
        {
          path: 'viewgrievance',
          component: ViewgrievanceComponent,
          data: {
            title: 'View Grievance'
          }
        },
        {
          path: 'assignedgrievance',
          component: AssignedgrievanceComponent,
          data: {
            title: 'Assigned Grievance'
          }
        }
      ]
    }
  ];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
export class grievancesRoutingModule{

}