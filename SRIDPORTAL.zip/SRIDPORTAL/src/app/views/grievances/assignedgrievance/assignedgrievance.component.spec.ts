import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignedgrievanceComponent } from './assignedgrievance.component';

describe('AssignedgrievanceComponent', () => {
  let component: AssignedgrievanceComponent;
  let fixture: ComponentFixture<AssignedgrievanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignedgrievanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedgrievanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
