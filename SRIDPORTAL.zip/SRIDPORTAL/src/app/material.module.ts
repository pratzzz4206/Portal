import { NgModule } from '@angular/core';
import {MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule,MatTabsModule,MatTableModule,MatCheckboxModule} from '@angular/material';

@NgModule({
    imports:[ MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule,MatTabsModule,MatTableModule,MatCheckboxModule],
    exports:[ MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule,MatTabsModule,MatTableModule,MatCheckboxModule]
})
export class materialModule{

}