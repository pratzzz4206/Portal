import { NgModule } from '@angular/core';
import {MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule} from '@angular/material';

@NgModule({
    imports:[ MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule],
    exports:[ MatMenuModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatButtonModule]
})
export class materialModule{

}